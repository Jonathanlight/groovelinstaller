<?php

namespace Illuminate\Http\Exception;

use Exception;

class PostTooLargeException extends Exception
{
}
