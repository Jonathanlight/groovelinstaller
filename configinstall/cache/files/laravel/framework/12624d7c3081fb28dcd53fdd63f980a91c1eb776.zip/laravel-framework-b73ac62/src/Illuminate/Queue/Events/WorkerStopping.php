<?php

namespace Illuminate\Queue\Events;

class WorkerStopping
{
    //
}
