<?php

namespace Namespaced;

class Foo
{
    public static $loaded = true;
}
