<html>
<head>
<meta charset="utf-8"/>
<title>404 - this page does not exist</title>
<style>
.logo {
    text-align: center;
    margin-top: 200px;
}
.wrap {
    margin: 0px auto;
    width: 1000px;
}

body {
    background: none repeat scroll 0% 0% #EAEAEA;
    font-family: "Love Ya Like A Sister",cursive;
}
</style>
</head>
<body>

 

<body>
 <div class="wrap">
	<div class="logo">
			<p>OOPS! - Could not Find it</p>
			 {!!HTML::image('packages/groovel/cmsgroovel/groovel/admin/images/404-1.png')!!}
			<div class="sub">
			  <p><a href="/">Back </a></p>
			</div>
	</div>
 </div>	

</body>
</html>