<html>
<head>
<meta charset="utf-8"/>
<title>403 - Permission Denied</title>
<style>
.logo {
    text-align: center;
    margin-top: 200px;
}
.wrap {
    margin: 0px auto;
    width: 1000px;
}

body {
    background: none repeat scroll 0% 0% #EAEAEA;
    font-family: "Love Ya Like A Sister",cursive;
}
</style>
</head>
<body>

 

<body>
 <div class="wrap">
	<div class="logo">
			<p style='font-size:100px;color:red'>OOPS! - Permission denied</p>
			<div class="sub">
			  <p><a href="/">Back </a></p>
			</div>
	</div>
 </div>	

</body>
</html>