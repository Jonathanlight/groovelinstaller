<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="../../assets/ico/favicon.ico">

    <title>Groovel Platform</title>

     {!!HTML::style('packages/groovel/cmsgroovel/bootstrap/css/bootstrap.min.css')!!}
      {!!HTML::style('packages/groovel/cmsgroovel/groovel/admin/css/common.css')!!}
    {!!HTML::style('packages/groovel/cmsgroovel/groovel/admin/css/route.css')!!}
    {!! HTML::script('packages/groovel/cmsgroovel/jquery/js/jquery-1.11.1.min.js') !!}
    
    {!! HTML::script('packages/groovel/cmsgroovel/groovel/admin/js/groovel_contents.js') !!}
    {!! HTML::script('packages/groovel/cmsgroovel/groovel/admin/js/groovel_forum.js') !!}
    {!! HTML::script('packages/groovel/cmsgroovel/groovel/admin/js/groovel_langages.js') !!}
    {!! HTML::script('packages/groovel/cmsgroovel/groovel/admin/js/groovel_packages.js') !!}
    {!! HTML::script('packages/groovel/cmsgroovel/groovel/admin/js/groovel_permissions.js') !!}
    {!! HTML::script('packages/groovel/cmsgroovel/groovel/admin/js/groovel_routes.js') !!}
    {!! HTML::script('packages/groovel/cmsgroovel/groovel/admin/js/groovel_users.js') !!}
    {!! HTML::script('packages/groovel/cmsgroovel/groovel/admin/js/groovel_functions.js') !!}
  
    {!! HTML::script('packages/groovel/cmsgroovel/bootstrap/js/bootstrap.js') !!}
    {!! HTML::script('packages/groovel/cmsgroovel/listjs/list.min.js') !!}
    