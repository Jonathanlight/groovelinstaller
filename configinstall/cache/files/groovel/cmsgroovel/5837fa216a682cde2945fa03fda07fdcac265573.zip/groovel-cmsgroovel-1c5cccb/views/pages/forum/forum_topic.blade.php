@extends('cmsgroovel.layouts.groovel_admin_forum')
@section('content')
@include('cmsgroovel.pages.forum.section.section_forum_topic')	            
@stop
 