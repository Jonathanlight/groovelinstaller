@extends('cmsgroovel.layouts.groovel_admin_forum')
@section('content')
<div id='forums' style='margin-top:100px'>
     
@include('cmsgroovel.pages.forum.section.section_list_forums')
</div>
@stop