<!--This is a blade template that goes in email message -->
<h1>Hi {!!$pseudo!!} </h1>

<p>
{!!$body!!}
</p>
<br/>
Yours
{!!$author!!}