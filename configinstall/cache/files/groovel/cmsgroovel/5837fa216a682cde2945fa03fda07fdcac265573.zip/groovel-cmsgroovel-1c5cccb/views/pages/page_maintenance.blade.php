<html>
<head>
<meta charset="utf-8"/>
<title>Site is on maintenance</title>
<style>
.logo {
    text-align: center;
    margin-top: 200px;
}
.wrap {
    margin: 0px auto;
    width: 1000px;
}

body {
    background: none repeat scroll 0% 0% #EAEAEA;
    font-family: "Love Ya Like A Sister",cursive;
}
</style>
</head>
<body>

 

<body>
 <div class="wrap">
	<div class="logo">
			<p style='font-size:100px;color:blue'>OOPS! - Maintenance is in progress Come in back soon</p>
			<div class="sub">
			  <p><a href="/">Back </a></p>
			</div>
	</div>
 </div>	

</body>
</html>