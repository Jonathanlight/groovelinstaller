@extends('cmsgroovel.layouts.groovel_admin_forum')
@section('content')
<div class='container-fluid'>
@include('cmsgroovel.pages.forum.section.section_forum')
</div>            
@stop