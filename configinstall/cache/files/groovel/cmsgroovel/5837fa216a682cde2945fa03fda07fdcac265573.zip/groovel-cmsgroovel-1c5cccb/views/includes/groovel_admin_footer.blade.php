<div id="copyright text-right">© Copyright 2014 François Varnier</div>

