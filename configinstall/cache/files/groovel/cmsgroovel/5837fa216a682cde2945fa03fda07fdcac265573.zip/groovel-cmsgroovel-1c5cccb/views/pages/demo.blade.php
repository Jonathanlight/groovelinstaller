<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width" />
      <title>template to do as you want</title>
       </head>
   <body class="size-1140">
<p>TO DO you can get and design the content as you want</p> 
   </body>
</html>