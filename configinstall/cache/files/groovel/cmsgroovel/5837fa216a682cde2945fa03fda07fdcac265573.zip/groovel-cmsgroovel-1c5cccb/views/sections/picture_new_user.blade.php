 @section('uploadfile')
 <div id="dvFiles" class="col-md-4"> 
	 <label for="my-file" class="input-file-trigger" tabindex="0">Select a picture...</label>
	 <input class="input-file" id="my-file" name="files" type="file">
	  <output id="input_list" class="file-return">
	  </output>
	 <output id="old_list" class="file-return">
	 </output>
	 <output id="list" class="file-return">
	     
	 </output>
</div>

@show

