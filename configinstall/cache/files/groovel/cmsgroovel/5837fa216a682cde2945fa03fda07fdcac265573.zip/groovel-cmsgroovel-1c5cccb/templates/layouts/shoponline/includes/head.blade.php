       <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width" />
      <title>Responsive Online Store template</title>
  
    {!!HTML::style('shoponline/styles/css/components.css')!!}
    {!!HTML::style('shoponline/styles/css/responsee.css')!!}
     <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
   
   
    {!! HTML::script('shoponline/styles/js/jquery-1.8.3.min.js') !!}
    {!! HTML::script('shoponline/styles/js/jquery-ui.min.js') !!}
    {!! HTML::script('shoponline/styles/js/modernizr.js') !!}
    {!! HTML::script('shoponline/styles/js/responsee.js') !!}
       
      
      
  