    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
     <title>Monitoring board template</title>
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">
    {!!HTML::style('monitoringonline/styles/vendors/bootstrap/css/bootstrap.min.css')!!}
    {!! HTML::style('monitoringonline/styles/css/styles.css') !!}
    {!!HTML::style('monitoringonline/styles/css/stats.css') !!}
     {!! HTML::script('packages/groovel/cmsgroovel/jquery/js/jquery-1.11.1.min.js') !!}
     {!!HTML::script('monitoringonline/styles/vendors/bootstrap/js/bootstrap.min.js') !!}
     {!! HTML::style('monitoringonline/styles/vendors/morris/morris.css')!!}
    
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
   
   
 
   

    {!! HTML::script('monitoringonline/styles/vendors/jquery.knob.js')!!}
    
    {!! HTML::script('monitoringonline/styles/vendors/raphael-min.js')!!}
 
    {!!HTML::script('monitoringonline/styles/vendors/flot/jquery.flot.js')!!}
    {!!HTML::script('monitoringonline/styles/vendors/flot/jquery.flot.categories.js')!!}
    {!!HTML::script('monitoringonline/styles/vendors/flot/jquery.flot.pie.js')!!}
    {!! HTML::script('monitoringonline/styles/vendors/flot/jquery.flot.time.js')!!}
    {!!HTML::script('monitoringonline/styles/vendors/flot/jquery.flot.stack.js')!!}
    {!!HTML::script('monitoringonline/styles/vendors/flot/jquery.flot.resize.js')!!}


 