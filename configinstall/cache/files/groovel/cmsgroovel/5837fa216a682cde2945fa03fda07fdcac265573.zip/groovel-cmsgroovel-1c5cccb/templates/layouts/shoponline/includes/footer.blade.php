 <!-- FOOTER -->
      <footer class="line">
         <div class="s-12 l-6">
            <p>Copyright 2015, Vision Design - graphic zoo</p>
         </div>
         <div class="s-12 l-6">
            <a class="right" href="http://www.myresponsee.com" title="Responsee - lightweight responsive framework">Design and coding by Responsee Team</a>
         </div>
      </footer>