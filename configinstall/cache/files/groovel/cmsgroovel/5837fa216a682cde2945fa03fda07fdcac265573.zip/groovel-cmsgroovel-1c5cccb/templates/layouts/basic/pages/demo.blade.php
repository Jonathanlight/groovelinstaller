@extends('base.core')
@section('content')
    <div class="row">
        <div class="col-md-12">
            From page 1
        </div>
    </div>
@stop