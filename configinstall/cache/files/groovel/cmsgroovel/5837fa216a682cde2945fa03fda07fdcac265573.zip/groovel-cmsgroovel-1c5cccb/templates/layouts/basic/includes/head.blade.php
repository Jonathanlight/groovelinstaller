    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  
    <title>Put your title</title>

    {!!HTML::style('packages/groovel/cmsgroovel/bootstrap/css/bootstrap.min.css')!!}
    {!! HTML::script('packages/groovel/cmsgroovel/jquery/js/jquery-1.11.1.min.js') !!}
    {!! HTML::script('packages/groovel/cmsgroovel/bootstrap/js/bootstrap.js') !!}
       
      
     