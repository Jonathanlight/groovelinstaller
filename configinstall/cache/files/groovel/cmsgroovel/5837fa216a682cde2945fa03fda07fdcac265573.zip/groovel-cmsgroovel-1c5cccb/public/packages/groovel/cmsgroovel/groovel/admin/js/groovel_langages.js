var langages=new Array();
langages['FR']='France';
langages['GB']='United Kingdom';
langages['US']='United States';