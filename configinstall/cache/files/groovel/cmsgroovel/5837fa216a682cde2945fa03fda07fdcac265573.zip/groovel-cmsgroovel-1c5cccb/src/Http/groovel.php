<?php
return array(

		//'elasticsearch' => 'localhost:9200',
		'host'=>'localhost',
		'port'=>'9200',
		'elasticsearch'=>'http://localhost:9200',
		'timeout'=>null
);